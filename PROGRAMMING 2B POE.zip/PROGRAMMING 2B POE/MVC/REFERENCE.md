# Reference


Microsoft (2025a) *ASP.NET Core MVC overview*. Available at: https://learn.microsoft.com/en-us/aspnet/core/mvc/overview 

Microsoft (2025b) *Session and app state in ASP.NET Core*. Available at: https://learn.microsoft.com/en-us/aspnet/core/fundamentals/app-state 

Microsoft (2025c) *Call a web API from an ASP.NET Core MVC app*. Available at: https://learn.microsoft.com/en-us/aspnet/core/fundamentals/http-requests 

Docker (2025) *Dockerfile reference*. Available at: https://docs.docker.com/reference/dockerfile