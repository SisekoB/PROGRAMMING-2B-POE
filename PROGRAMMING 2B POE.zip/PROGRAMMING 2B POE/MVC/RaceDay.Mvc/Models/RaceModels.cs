namespace RaceDay.Mvc.Models;

public record LoginVm(string Email, string Password);
public record RegisterVm(string FullName, string Email, string Password, string? Phone, string UserRole);
public record EventVm(int EventId, int OrganiserId, string Name, string? Description, string EventType, DateTime EventDate, string Location, decimal DistanceKm, int MaxParticipants);
public record CategoryVm(int CategoryId, string Name, string? Description);
public record EnrolmentVm(int EnrolmentId, int EventId, int ParticipantId, int CategoryId, DateTime EnrolmentDate, string EmergencyContactName, string EmergencyContactPhone, string EnrolmentStatus);
public record ResultVm(int ResultId, int EventId, int ParticipantId, TimeSpan? FinishTime, int? Position, string ResultStatus);
public record EventDetailsVm(EventVm Item, int[] CategoryIds, int AvailablePlaces);
public record ApiUser(int UserId, string FullName, string Email, string? Phone, string UserRole);
public record EventFormVm(string Name, string? Description, string EventType, DateTime EventDate, string Location, decimal DistanceKm, int MaxParticipants);
public record EnrolFormVm(int CategoryId, string EmergencyContactName, string EmergencyContactPhone);
