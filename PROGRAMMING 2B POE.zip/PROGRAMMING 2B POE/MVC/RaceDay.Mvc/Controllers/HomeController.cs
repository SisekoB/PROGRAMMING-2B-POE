using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

public class HomeController(ApiClient api) : Controller
{
    public async Task<IActionResult> Index(string? type, string? location) => View(await api.Events(type, location) ?? []);
    public async Task<IActionResult> Details(int id) { var item = await api.Event(id); return item == null ? NotFound() : View(item); }
}
