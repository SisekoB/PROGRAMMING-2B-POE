using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

public class ParticipantController(ApiClient api) : Controller
{
    private bool Allowed() => HttpContext.Session.GetString("Role") == "Participant";
    public async Task<IActionResult> MyEvents() => !Allowed() ? RedirectToAction("Login", "Account") : View(await api.MyEnrolments() ?? []);
    public IActionResult Enrol(int id, int categoryId) => !Allowed() ? RedirectToAction("Login", "Account") : View(new EnrolFormVm(categoryId, "", ""));
    [HttpPost] public async Task<IActionResult> Enrol(int id, EnrolFormVm model) { if (!Allowed()) return RedirectToAction("Login", "Account"); TempData["Message"] = await api.Enrol(id, model) ? "Enrolment saved." : "The enrolment could not be saved."; return RedirectToAction("Details", "Home", new { id }); }
    public async Task<IActionResult> Results(int id) => !Allowed() ? RedirectToAction("Login", "Account") : View(await api.Results(id) ?? []);
    public async Task<IActionResult> Profile() => !Allowed() ? RedirectToAction("Login", "Account") : View(await api.Me());
    [HttpPost] public async Task<IActionResult> Profile(ApiUser model) { await api.UpdateProfile(model); TempData["Message"] = "Profile updated."; return RedirectToAction(nameof(Profile)); }
}
