using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

public class AccountController(ApiClient api) : Controller
{
    public IActionResult Login() => View(new LoginVm("", ""));
    [HttpPost] public async Task<IActionResult> Login(LoginVm model) { var result = await api.Login(model); if (!result.Ok) { ModelState.AddModelError("", result.Message); return View(model); } HttpContext.Session.SetInt32("UserId", result.User!.UserId); HttpContext.Session.SetString("Role", result.User.UserRole); HttpContext.Session.SetString("Name", result.User.FullName); return RedirectToAction("Index", "Home"); }
    public IActionResult Register() => View(new RegisterVm("", "", "", "", "Participant"));
    [HttpPost] public async Task<IActionResult> Register(RegisterVm model) { var result = await api.Register(model); if (!result.Ok) { ModelState.AddModelError("", result.Message); return View(model); } return RedirectToAction(nameof(Login)); }
    public async Task<IActionResult> Logout() { await api.Logout(); HttpContext.Session.Clear(); return RedirectToAction("Index", "Home"); }
}
