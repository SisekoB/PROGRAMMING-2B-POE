using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

public class OrganiserController(ApiClient api) : Controller
{
    private bool Allowed() => HttpContext.Session.GetString("Role") == "Organiser";
    public async Task<IActionResult> Dashboard() => !Allowed() ? RedirectToAction("Login", "Account") : View(await api.Events() ?? []);
    public IActionResult CreateEvent() => !Allowed() ? RedirectToAction("Login", "Account") : View(new EventFormVm("", "", "Running", DateTime.Today.AddDays(7), "", 5, 100));
    [HttpPost] public async Task<IActionResult> CreateEvent(EventFormVm model) { if (!Allowed()) return RedirectToAction("Login", "Account"); if (!await api.CreateEvent(model)) ModelState.AddModelError("", "Please check the event details."); else return RedirectToAction(nameof(Dashboard)); return View(model); }
    public async Task<IActionResult> DeleteEvent(int id) { if (Allowed()) await api.DeleteEvent(id); return RedirectToAction(nameof(Dashboard)); }
}
