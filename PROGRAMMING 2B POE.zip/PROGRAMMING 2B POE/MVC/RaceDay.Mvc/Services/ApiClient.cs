using System.Net.Http.Json;
using System.Text.Json;
using RaceDay.Mvc.Models;

namespace RaceDay.Mvc.Services;

public class ApiClient
{
    private readonly HttpClient _http;
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);
    public ApiClient(HttpClient http) => _http = http;

    public async Task<(bool Ok, string Message, ApiUser? User)> Login(LoginVm model)
    {
        var response = await _http.PostAsJsonAsync("api/auth/login", model);
        if (!response.IsSuccessStatusCode) return (false, "Email or password is incorrect.", null);
        var user = await response.Content.ReadFromJsonAsync<ApiUser>(JsonOptions);
        return (true, "", user);
    }
    public async Task<(bool Ok, string Message)> Register(RegisterVm model)
    {
        var response = await _http.PostAsJsonAsync("api/auth/register", model);
        return response.IsSuccessStatusCode ? (true, "") : (false, await response.Content.ReadAsStringAsync());
    }
    public async Task Logout() => await _http.PostAsync("api/auth/logout", null);
    public Task<List<EventVm>?> Events(string? type = null, string? location = null) => _http.GetFromJsonAsync<List<EventVm>>($"api/events?type={Uri.EscapeDataString(type ?? "")}&location={Uri.EscapeDataString(location ?? "")}", JsonOptions);
    public Task<EventDetailsVm?> Event(int id) => _http.GetFromJsonAsync<EventDetailsVm>($"api/events/{id}", JsonOptions);
    public Task<List<CategoryVm>?> Categories() => _http.GetFromJsonAsync<List<CategoryVm>>("api/categories", JsonOptions);
    public Task<List<EnrolmentVm>?> MyEnrolments() => _http.GetFromJsonAsync<List<EnrolmentVm>>("api/users/me/enrolments", JsonOptions);
    public Task<ApiUser?> Me() => _http.GetFromJsonAsync<ApiUser>("api/users/me", JsonOptions);
    public Task<List<ResultVm>?> Results(int eventId) => _http.GetFromJsonAsync<List<ResultVm>>($"api/events/{eventId}/results", JsonOptions);
    public async Task<bool> Enrol(int eventId, EnrolFormVm model) => (await _http.PostAsJsonAsync($"api/events/{eventId}/enrolments", model)).IsSuccessStatusCode;
    public async Task<bool> CreateEvent(EventFormVm model) => (await _http.PostAsJsonAsync("api/events", model)).IsSuccessStatusCode;
    public async Task<bool> DeleteEvent(int id) => (await _http.DeleteAsync($"api/events/{id}")).IsSuccessStatusCode;
    public async Task<bool> AddCategory(int eventId, int categoryId) => (await _http.PostAsync($"api/events/{eventId}/categories/{categoryId}", null)).IsSuccessStatusCode;
    public async Task<bool> UpdateProfile(ApiUser model) => (await _http.PutAsJsonAsync("api/users/me", new { model.FullName, model.Phone })).IsSuccessStatusCode;
}
