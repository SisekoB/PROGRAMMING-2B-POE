# RaceDay Part 3 - MVC web application

This submission adds a simple ASP.NET Core MVC front end to the Part 2 RaceDay API. The MVC application only uses `ApiClient` for data operations; it does not connect to SQL Server and does not copy the API's business rules.

## Run locally

1. Start the Part 2 API first (`dotnet run --project "../PROGRAMMING 2B PART 2/RaceDay.Api/RaceDay.Api.csproj"`).
2. Check `RaceDay.Mvc/appsettings.json` and change `ApiBaseUrl` if the API uses another port.
3. Run `dotnet restore`, `dotnet build`, and `dotnet run --project RaceDay.Mvc/RaceDay.Mvc.csproj`.
4. Open the HTTPS/HTTP URL printed by .NET.

## Docker

From this folder run: `docker build -t raceday-mvc .` and then `docker run --rm -p 8080:8080 -e ApiBaseUrl=http://host.docker.internal:5000/ raceday-mvc`.

## Features mapped to the rubric

- Login, registration, server session state, role-aware navigation and logout.
- Participant event browsing/filtering, event details, enrolment, personal events, results and profile.
- Organiser dashboard and event creation/deletion.
- Responsive RaceDay branding, clear status colours and friendly validation messages.
- Dockerfile and GitHub Actions build workflow.

## Evidence still required from the student

Record an unlisted video showing the running API, Swagger endpoints, both roles, enrolment/results, the MVC pages and Docker startup. Add the final YouTube URL below before submission:

`Video link: TODO - paste the unlisted YouTube URL here`

## References (Harvard style)

Independent Institute of Education (2026) *POE - Automation of Web Application: Programming 2B*. Course assignment brief.

Microsoft (2025a) *ASP.NET Core MVC overview*. Available at: https://learn.microsoft.com/en-us/aspnet/core/mvc/overview (Accessed: 9 November 2026).

Microsoft (2025b) *Session and app state in ASP.NET Core*. Available at: https://learn.microsoft.com/en-us/aspnet/core/fundamentals/app-state (Accessed: 9 November 2026).

Microsoft (2025c) *Call a web API from an ASP.NET Core MVC app*. Available at: https://learn.microsoft.com/en-us/aspnet/core/fundamentals/http-requests (Accessed: 9 November 2026).

Docker (2025) *Dockerfile reference*. Available at: https://docs.docker.com/reference/dockerfile/ (Accessed: 9 November 2026).
